﻿using System.Windows.Forms;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Drawing;


namespace BasicQueuingSystem
{
    public partial class CashierWindowQueue : Form
    {
        public CashierWindowQueue()
        {

            CashierClass cashier = new CashierClass();
            InitializeComponent();
        }
  

        private void btnRefresh_Click(object sender, System.EventArgs e)
        {
            DisplayCashierQueue(CashierClass.CashierQueue);
        }
        private void timer1__tick(object sender, System.EventArgs e)
        {
            DisplayCashierQueue(CashierClass.CashierQueue);
        }
        public void DisplayCashierQueue(IEnumerable CashierList)
        {
            listCashierQueue.Items.Clear();
            foreach(object obj in CashierList)
            {
                listCashierQueue.Items.Add(obj.ToString());
            }
        }
    }
}
