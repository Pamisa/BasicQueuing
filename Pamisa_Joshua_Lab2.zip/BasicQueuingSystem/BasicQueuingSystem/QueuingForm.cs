﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BasicQueuingSystem
{
    public partial class QueuingForm : Form
    {
       
        CashierClass cashier = new CashierClass();
        CashierWindowQueue csw = new CashierWindowQueue();
        
        public QueuingForm()
        {
            InitializeComponent();
            csw.Show();
        
        }



        private void button1_Click(object sender, EventArgs e)
        {
            lblQueue.Text = cashier.CashierGeneratedNumber("P - ");
            CashierClass.getNumberInQueue = lblQueue.Text;
            CashierClass.CashierQueue.Enqueue(CashierClass.getNumberInQueue);
            
    
        }
       

        private void lblQueue_Click(object sender, EventArgs e)
        {
  
        }
    }
   
       
            
}
